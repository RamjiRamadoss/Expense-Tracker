"""
AndroidToast
============

Copyright (c) 2013 Brian Knapp

For suggestions and questions:
<kivydevelopment@gmail.com>

This file is distributed under the terms of the same license,
as the Kivy framework.
"""

from .androidtoast import toast
