# ExTrac

<img align="left" height="128" src="https://github.com/adityabhawsingka/ExpenseTracker/blob/master/app/data/images/icon.png">

This is an Android app developed using Python, Kivy and KivyMD. Users will be able to maintain a list of expenses done over several days, months and years.

You can dowload the app from Google Play Store at:

https://play.google.com/store/apps/details?id=org.abhawsingka.extrac


Contributing
------------

You are welcome to improve and suggest changes to this application.
